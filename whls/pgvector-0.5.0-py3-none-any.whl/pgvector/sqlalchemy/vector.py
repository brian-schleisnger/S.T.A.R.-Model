from sqlalchemy.dialects.postgresql.base import ischema_names
from sqlalchemy.types import UserDefinedType, TypeEngine, Float, String
from sqlalchemy import Dialect, Operators
from typing import Any
from .. import Vector


class VECTOR(UserDefinedType[Any]):
    cache_ok = True
    _string = String()

    def __init__(self, dim: int | None = None) -> None:
        super().__init__()
        self.dim = dim

    def get_col_spec(self, **kw: Any) -> str:
        if self.dim is None:
            return 'VECTOR'
        return 'VECTOR(%d)' % self.dim

    def bind_processor(self, dialect: Dialect) -> Any:
        def process(value: Any) -> str | None:
            return Vector._to_db(value)
        return process

    def literal_processor(self, dialect: Dialect) -> Any:
        string_literal_processor = self._string._cached_literal_processor(dialect)

        def process(value: Any) -> Any:
            return string_literal_processor(Vector._to_db(value))  # type: ignore
        return process

    def result_processor(self, dialect: Dialect, coltype: Any) -> Any:
        def process(value: Any) -> list[float] | None:
            return Vector._from_db(value)
        return process

    class Comparator(TypeEngine.Comparator[Any]):
        def l2_distance(self, other: object, /) -> Operators:
            return self.op('<->', return_type=Float)(other)

        def max_inner_product(self, other: object, /) -> Operators:
            return self.op('<#>', return_type=Float)(other)

        def cosine_distance(self, other: object, /) -> Operators:
            return self.op('<=>', return_type=Float)(other)

        def l1_distance(self, other: object, /) -> Operators:
            return self.op('<+>', return_type=Float)(other)

    comparator_factory = Comparator


# for reflection
ischema_names['vector'] = VECTOR  # type: ignore
